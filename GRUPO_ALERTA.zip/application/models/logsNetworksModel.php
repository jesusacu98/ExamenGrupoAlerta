<?php
/**
 *
 */
class LogsNetworksModel extends CI_Model
{

  function __construct()
  {
    $this->load->database();
  }

  public function getAll()
  {
    $result = $this->db->query('select * from logs_networks');
    $datos = $result->result_array();
    return $datos;
  }

  public function InsertData()
  {
    $this->db->db_debug = false;

    $json = file_get_contents('php://input');
    $data = json_decode($json);

    if ($data == NULL) {
      $error = [
        'result' => false,
        'message_error' => 'Datos no enviados'
        ];
      return $error;
    }
    if (!empty($data->wifi_name) && !empty($data->wifi_rssi) && !empty($data->bluetooth_devices)) {
      $error = [
        'result' => false,
        'message_error' => 'Formato no correcto'
        ];
    }
    $query = "insert into logs_networks (wifi_name, wifi_rssi, bluetooth_devices)
      values ('".$data->wifi_name."','".$data->wifi_rssi."','".$data->bluetooth_devices."')";

    if(!@$this->db->query($query))
    {
        $error = $this->db->error();
        return false;
    }else{
        return true;
    }
  }
}
