<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Networks extends CI_Controller {

  function __construct()
  {
    parent :: __construct();
    $this->load->model('LogsNetworksModel');
  }

	public function index()
	{

	}

  public function LoadData()
  {
    $result = $this->LogsNetworksModel->getAll();
    $data = $this->output->set_content_type('application/json')->set_output(json_encode($result));
    // var_dump($data);exit;
  }

  public function InsertData()
  {
    $result['result'] = $this->LogsNetworksModel->InsertData();
    ($result['result'] === TRUE) ? $result['message'] = "Se han agregado los datos correctamente" : $result['message'] = "Ha ocurrido un error";  
    $data = $this->output->set_content_type('application/json')->set_output(json_encode($result));
  }
}
