package com.example.examengrupoalerta;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    Button btnEnviarData,
            btn_ObtenerRed,
            btnFindBT,
            btnRefreshBT,
            btnSend;
    TextView textNombreRed, textRssi,status,result;
    Switch switchBT;

    //Cambiar la ip de la compu donde esta el backend
    public String ruta = "http://192.168.0.104/GRUPO_ALERTA/Networks/InsertData",
            wifi_name,
            rssi;

    private LocationSettingsRequest.Builder builder;
    private final  int REQUEST_CHECK_CODE = 8989;
    public ListView listBTDevices;

    public BluetoothAdapter mBtAdapter;

    private ArrayList<String> DeviceBt;
    private ArrayAdapter<String> adaptador1;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mBroadcastReceiver3);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instanciar objetos de la vista
        findViewByIdes();

        //Activar modo estricto para que me permita realizar peticiones en el hilo principal
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //Cargar el funcionamiento de la app
        Acciones();

    }
    //Diferentes funcionalidades
    public void Acciones(){
        //Permiso GPS
        PermisoGPS();
        //Encender GPS
        TurnOnGps();

        //Bluetooth
        mBtAdapter = BluetoothAdapter.getDefaultAdapter(); //Retorna el adaptador del bluetooth
        if(mBtAdapter == null){
            Toast.makeText(getApplicationContext(),"Adaptador no soportado",Toast.LENGTH_LONG).show();
        }
        //Adaptador de BT
        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        //Validacion para el boton de prender/apagar bluetooth
        if (!mBtAdapter.isEnabled()) {
            switchBT.setChecked(false);
        }else {
            switchBT.setChecked(true);
        }
        //Instanciar array para guardar los dispositivos bluetooth
        DeviceBt=new ArrayList<String>();

        //Encender bluetooth
        switchBT.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mBtAdapter.enable();
                } else {
                    mBtAdapter.disable();
                }
            }
        });
        //Obtener el nombre de la red WIFI y el rssi
        btn_ObtenerRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String res = mostrarNombreConexion(getApplicationContext(), "name");
                if (TextUtils.equals(res, "<unknown ssid>")){
                    textNombreRed.setText("");
                    textRssi.setText("");
                    Toast.makeText(getApplicationContext(),"Favor de enceder GPS",Toast.LENGTH_LONG).show();
                    TurnOnGps();
                }else {
                    String name = mostrarNombreConexion(getApplicationContext(), "name");
                    String rss = mostrarNombreConexion(getApplicationContext(), "rssi");
                    textNombreRed.setText(name);
                    textRssi.setText(rss);
                    wifi_name = name;
                    rssi = rss;
                }
            }
        });
        //Web Service
        btnEnviarData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String res = sendData();
                if (res == "") {
                    Toast.makeText(getApplicationContext(),"Nada por agregar",Toast.LENGTH_SHORT).show();
                }else {
                    if(res.contains("false:")){
                        Toast.makeText(getApplicationContext(),"No se ha podido conectar con el servidor",Toast.LENGTH_SHORT).show();
                    }else{
                        try {
                            Gson gson = new Gson();
                            Properties properties = gson.fromJson(res, Properties.class);
                            Toast.makeText(getApplicationContext(),properties.getProperty("message"),Toast.LENGTH_SHORT).show();
                        }catch (Exception e){
                            Toast.makeText(getApplicationContext(),"Ha ocurrido un error: "+ e,Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
    //Funcion para enviar la información a la bd
    public String sendData(){
        String param = "";
        String respuesta = "";
        String wifi_name = (String) textNombreRed.getText();
        String rssi_name = (String) textRssi.getText();
        Gson gson = new Gson();
        try {
            if (wifi_name != "" && rssi_name != "" && DeviceBt.size() > 0){
                JSONObject jsonObject= new JSONObject();
                jsonObject.put("wifi_name", wifi_name);
                jsonObject.put("wifi_rssi", rssi_name);
                JSONArray jsonObjectBT= new JSONArray();
                for (int i=0;i<DeviceBt.size();i++) {
                    jsonObjectBT.put(DeviceBt.get(i));
                }
                //String stringBT = gson.toJson(jsonObjectBT).toString();
                String stringBT = JsonUtil.toPrettyFormatArray(jsonObjectBT.toString());
                jsonObject.put("bluetooth_devices", stringBT);
                param = JsonUtil.toPrettyFormat(jsonObject.toString());
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(ruta);
                    connection=(HttpURLConnection)url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setRequestProperty("Content-Length","application/json; charset=UTF-8");

                    OutputStream os = connection.getOutputStream();
                    os.write(param.getBytes("UTF-8"));
                    os.close();

                    // read the response
                    Scanner in = new Scanner(connection.getInputStream());
                    while (in.hasNextLine())
                        respuesta += (in.nextLine());

                    in.close();
                    connection.disconnect();
                }catch (Exception e){
                    return "false: "+e;
                }
            }else {
                return respuesta;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return respuesta;
    }
    //Funcion para darle mejor formato al json
    public static class JsonUtil {
        public static String toPrettyFormat(String jsonString)
        {
            JsonParser parser = new JsonParser();
            JsonObject json = parser.parse(jsonString).getAsJsonObject();

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String prettyJson = gson.toJson(json);

            return prettyJson;
        }
        public static String toPrettyFormatArray(String jsonString)
        {
            JsonParser parser = new JsonParser();
            JsonArray json = parser.parse(jsonString).getAsJsonArray();

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String prettyJson = gson.toJson(json);

            return prettyJson;
        }
    }
    //Funcion para obtener las credenciales de la red WiFi
    public static String mostrarNombreConexion(Context context, String param) {
        int numberOfLevels = 5;
        String Vreturn = null;
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (networkInfo.isConnected()) {
            final WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            final WifiInfo connectionInfo = wifiManager.getConnectionInfo();
            if (connectionInfo != null && !TextUtils.isEmpty(connectionInfo.getSSID())) {
                if (param.equals("name")){
                    Vreturn = connectionInfo.getSSID();
                }else {
                    Vreturn = String.valueOf(WifiManager.calculateSignalLevel(connectionInfo.getRssi(), numberOfLevels));
                }
            }
        }
        return Vreturn;
    }
    //Funcion para encender el GPS
    public void TurnOnGps(){
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest);
        Task<LocationSettingsResponse> result =
                LocationServices.getSettingsClient(this).checkLocationSettings(builder.build());
        result.addOnCompleteListener(new OnCompleteListener<LocationSettingsResponse>() {
            @Override
            public void onComplete(@NonNull Task<LocationSettingsResponse> task) {
                try {
                    task.getResult(ApiException.class);
                } catch (ApiException e) {
                    switch (e.getStatusCode()){
                        case LocationSettingsStatusCodes
                                .RESOLUTION_REQUIRED:

                            try {
                                ResolvableApiException resolvableApiException = (ResolvableApiException) e;
                                resolvableApiException.startResolutionForResult(MainActivity.this, REQUEST_CHECK_CODE);
                            } catch (IntentSender.SendIntentException ex) {
                                ex.printStackTrace();
                            }catch (ClassCastException ex){

                            }
                            break;
                        case LocationSettingsStatusCodes.
                                SETTINGS_CHANGE_UNAVAILABLE:
                        {
                            break;
                        }

                    }
                    e.printStackTrace();
                }
            }
        });
    }
    //Funcion para dar permiso a la app de GPS
    public void PermisoGPS(){
        int permiso = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
        if (permiso == PackageManager.PERMISSION_DENIED){
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)){

            }else {
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
            }
        }
    }
    //Funcion para instansear los objetos de la vista
    private void findViewByIdes() {
        btnEnviarData = (Button) findViewById(R.id.btn_enviarData);
        btn_ObtenerRed = (Button) findViewById(R.id.btn_ObtenerRed);
        btnFindBT = (Button) findViewById(R.id.btnFindBT);
        textNombreRed = (TextView) findViewById(R.id.textNombreRed);
        textRssi = (TextView) findViewById(R.id.textRssi);
        status = (TextView) findViewById(R.id.status);
        listBTDevices = (ListView) findViewById(R.id.listBTDevices);
        switchBT = (Switch) findViewById(R.id.switchBT);
    }
    //Funcion para buscar dispositivos bluetooth
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void btnDiscover(View view) {
//        Log.d(TAG, "btnDiscover: Looking for unpaired devices.");
        if (mBtAdapter.isEnabled()){
            switchBT.setChecked(true);
            if(mBtAdapter.isDiscovering()){
                status.setText("Buscando...");
                mBtAdapter.cancelDiscovery();

                //check BT permissions in manifest
                checkBTPermissions();

                mBtAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }
            if(!mBtAdapter.isDiscovering()){
                status.setText("Buscando...");
                //check BT permissions in manifest
                checkBTPermissions();

                mBtAdapter.startDiscovery();
                IntentFilter discoverDevicesIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
                registerReceiver(mBroadcastReceiver3, discoverDevicesIntent);
            }
        }else {
            Toast.makeText(getApplicationContext(),"Bluetooth desactivado",Toast.LENGTH_SHORT).show();
            switchBT.setChecked(false);
        }
    }
    //Funcion para verificar en el manifest los permisos necesarios
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void checkBTPermissions() {
        if(Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP){
            int permissionCheck = this.checkSelfPermission("Manifest.permission.ACCESS_FINE_LOCATION");
            permissionCheck += this.checkSelfPermission("Manifest.permission.ACCESS_COARSE_LOCATION");
            if (permissionCheck != 0) {

                this.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001); //Any number
            }
        }else{
            Toast.makeText(getApplicationContext(),"No tienes permisos de bluetooth",Toast.LENGTH_SHORT).show();
        }
    }
    // BroadcastReceiver para el servicio de busqueda de bluetooth
    private final BroadcastReceiver mBroadcastReceiver3 = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (!DeviceBt.contains(device.getName() + "\n" + device.getAddress())) {
                    DeviceBt.add(device.getName() + "\n" + device.getAddress());
                    status.setText("");
                }
                adaptador1=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,DeviceBt);
                listBTDevices.setAdapter(adaptador1);
            }
        }
    };

}